﻿namespace WindowsFormsApplication1
{
    partial class AR2gen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvl1Check = new System.Windows.Forms.CheckBox();
            this.lvl2Check = new System.Windows.Forms.CheckBox();
            this.lvl3Check = new System.Windows.Forms.CheckBox();
            this.lvl4Check = new System.Windows.Forms.CheckBox();
            this.lvl5Check = new System.Windows.Forms.CheckBox();
            this.lvl6Check = new System.Windows.Forms.CheckBox();
            this.lvl7Check = new System.Windows.Forms.CheckBox();
            this.lvl8Check = new System.Windows.Forms.CheckBox();
            this.lvl9Check = new System.Windows.Forms.CheckBox();
            this.lvlACheck = new System.Windows.Forms.CheckBox();
            this.lvlBCheck = new System.Windows.Forms.CheckBox();
            this.lvlCCheck = new System.Windows.Forms.CheckBox();
            this.lvlDCheck = new System.Windows.Forms.CheckBox();
            this.lvlECheck = new System.Windows.Forms.CheckBox();
            this.levelBox = new System.Windows.Forms.NumericUpDown();
            this.levelLabel = new System.Windows.Forms.Label();
            this.livesLabel = new System.Windows.Forms.Label();
            this.timerLabel = new System.Windows.Forms.Label();
            this.passBox = new System.Windows.Forms.TextBox();
            this.passLabel = new System.Windows.Forms.Label();
            this.lvlFCheck = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.levelBox)).BeginInit();
            this.SuspendLayout();
            // 
            // lvl1Check
            // 
            this.lvl1Check.AutoSize = true;
            this.lvl1Check.Location = new System.Drawing.Point(13, 17);
            this.lvl1Check.Name = "lvl1Check";
            this.lvl1Check.Size = new System.Drawing.Size(67, 17);
            this.lvl1Check.TabIndex = 0;
            this.lvl1Check.Text = "Industen";
            this.lvl1Check.UseVisualStyleBackColor = true;
            this.lvl1Check.CheckedChanged += new System.EventHandler(this.lvl1Check_CheckedChanged);
            // 
            // lvl2Check
            // 
            this.lvl2Check.AutoSize = true;
            this.lvl2Check.Location = new System.Drawing.Point(13, 40);
            this.lvl2Check.Name = "lvl2Check";
            this.lvl2Check.Size = new System.Drawing.Size(101, 17);
            this.lvl2Check.TabIndex = 1;
            this.lvl2Check.Text = "Tortoise Island?";
            this.lvl2Check.UseVisualStyleBackColor = true;
            this.lvl2Check.CheckedChanged += new System.EventHandler(this.lvl2Check_CheckedChanged);
            // 
            // lvl3Check
            // 
            this.lvl3Check.AutoSize = true;
            this.lvl3Check.Location = new System.Drawing.Point(13, 63);
            this.lvl3Check.Name = "lvl3Check";
            this.lvl3Check.Size = new System.Drawing.Size(62, 17);
            this.lvl3Check.TabIndex = 2;
            this.lvl3Check.Text = "Modero";
            this.lvl3Check.UseVisualStyleBackColor = true;
            this.lvl3Check.CheckedChanged += new System.EventHandler(this.lvl3Check_CheckedChanged);
            // 
            // lvl4Check
            // 
            this.lvl4Check.AutoSize = true;
            this.lvl4Check.Location = new System.Drawing.Point(12, 86);
            this.lvl4Check.Name = "lvl4Check";
            this.lvl4Check.Size = new System.Drawing.Size(86, 17);
            this.lvl4Check.TabIndex = 3;
            this.lvl4Check.Text = "Death Field?";
            this.lvl4Check.UseVisualStyleBackColor = true;
            this.lvl4Check.CheckedChanged += new System.EventHandler(this.lvl4Check_CheckedChanged);
            // 
            // lvl5Check
            // 
            this.lvl5Check.AutoSize = true;
            this.lvl5Check.Location = new System.Drawing.Point(12, 109);
            this.lvl5Check.Name = "lvl5Check";
            this.lvl5Check.Size = new System.Drawing.Size(59, 17);
            this.lvl5Check.TabIndex = 4;
            this.lvl5Check.Text = "Palace";
            this.lvl5Check.UseVisualStyleBackColor = true;
            this.lvl5Check.CheckedChanged += new System.EventHandler(this.lvl5Check_CheckedChanged);
            // 
            // lvl6Check
            // 
            this.lvl6Check.AutoSize = true;
            this.lvl6Check.Location = new System.Drawing.Point(12, 132);
            this.lvl6Check.Name = "lvl6Check";
            this.lvl6Check.Size = new System.Drawing.Size(59, 17);
            this.lvl6Check.TabIndex = 5;
            this.lvl6Check.Text = "Gratis?";
            this.lvl6Check.UseVisualStyleBackColor = true;
            this.lvl6Check.CheckedChanged += new System.EventHandler(this.lvl6Check_CheckedChanged);
            // 
            // lvl7Check
            // 
            this.lvl7Check.AutoSize = true;
            this.lvl7Check.Location = new System.Drawing.Point(12, 155);
            this.lvl7Check.Name = "lvl7Check";
            this.lvl7Check.Size = new System.Drawing.Size(106, 17);
            this.lvl7Check.TabIndex = 6;
            this.lvl7Check.Text = "Tower of Souls 1";
            this.lvl7Check.UseVisualStyleBackColor = true;
            this.lvl7Check.CheckedChanged += new System.EventHandler(this.lvl7Check_CheckedChanged);
            // 
            // lvl8Check
            // 
            this.lvl8Check.AutoSize = true;
            this.lvl8Check.Location = new System.Drawing.Point(140, 17);
            this.lvl8Check.Name = "lvl8Check";
            this.lvl8Check.Size = new System.Drawing.Size(62, 17);
            this.lvl8Check.TabIndex = 7;
            this.lvl8Check.Text = "Benefic";
            this.lvl8Check.UseVisualStyleBackColor = true;
            this.lvl8Check.CheckedChanged += new System.EventHandler(this.lvl8Check_CheckedChanged);
            // 
            // lvl9Check
            // 
            this.lvl9Check.AutoSize = true;
            this.lvl9Check.Location = new System.Drawing.Point(140, 40);
            this.lvl9Check.Name = "lvl9Check";
            this.lvl9Check.Size = new System.Drawing.Size(65, 17);
            this.lvl9Check.TabIndex = 8;
            this.lvl9Check.Text = "Atheria?";
            this.lvl9Check.UseVisualStyleBackColor = true;
            this.lvl9Check.CheckedChanged += new System.EventHandler(this.lvl9Check_CheckedChanged);
            // 
            // lvlACheck
            // 
            this.lvlACheck.AutoSize = true;
            this.lvlACheck.Location = new System.Drawing.Point(140, 63);
            this.lvlACheck.Name = "lvlACheck";
            this.lvlACheck.Size = new System.Drawing.Size(101, 17);
            this.lvlACheck.TabIndex = 9;
            this.lvlACheck.Text = "Demon\'s Cave?";
            this.lvlACheck.UseVisualStyleBackColor = true;
            this.lvlACheck.CheckedChanged += new System.EventHandler(this.lvlACheck_CheckedChanged);
            // 
            // lvlBCheck
            // 
            this.lvlBCheck.AutoSize = true;
            this.lvlBCheck.Location = new System.Drawing.Point(140, 86);
            this.lvlBCheck.Name = "lvlBCheck";
            this.lvlBCheck.Size = new System.Drawing.Size(70, 17);
            this.lvlBCheck.TabIndex = 10;
            this.lvlBCheck.Text = "Almetha?";
            this.lvlBCheck.UseVisualStyleBackColor = true;
            this.lvlBCheck.CheckedChanged += new System.EventHandler(this.lvlBCheck_CheckedChanged);
            // 
            // lvlCCheck
            // 
            this.lvlCCheck.AutoSize = true;
            this.lvlCCheck.Location = new System.Drawing.Point(140, 109);
            this.lvlCCheck.Name = "lvlCCheck";
            this.lvlCCheck.Size = new System.Drawing.Size(81, 17);
            this.lvlCCheck.TabIndex = 11;
            this.lvlCCheck.Text = "Deception?";
            this.lvlCCheck.UseVisualStyleBackColor = true;
            this.lvlCCheck.CheckedChanged += new System.EventHandler(this.lvlCCheck_CheckedChanged);
            // 
            // lvlDCheck
            // 
            this.lvlDCheck.AutoSize = true;
            this.lvlDCheck.Location = new System.Drawing.Point(140, 132);
            this.lvlDCheck.Name = "lvlDCheck";
            this.lvlDCheck.Size = new System.Drawing.Size(80, 17);
            this.lvlDCheck.TabIndex = 12;
            this.lvlDCheck.Text = "Stormrook?";
            this.lvlDCheck.UseVisualStyleBackColor = true;
            this.lvlDCheck.CheckedChanged += new System.EventHandler(this.lvlDCheck_CheckedChanged);
            // 
            // lvlECheck
            // 
            this.lvlECheck.AutoSize = true;
            this.lvlECheck.Location = new System.Drawing.Point(140, 155);
            this.lvlECheck.Name = "lvlECheck";
            this.lvlECheck.Size = new System.Drawing.Size(106, 17);
            this.lvlECheck.TabIndex = 13;
            this.lvlECheck.Text = "Tower of Souls 2";
            this.lvlECheck.UseVisualStyleBackColor = true;
            this.lvlECheck.CheckedChanged += new System.EventHandler(this.lvlECheck_CheckedChanged);
            // 
            // levelBox
            // 
            this.levelBox.Location = new System.Drawing.Point(255, 40);
            this.levelBox.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.levelBox.Name = "levelBox";
            this.levelBox.Size = new System.Drawing.Size(120, 20);
            this.levelBox.TabIndex = 14;
            this.levelBox.ValueChanged += new System.EventHandler(this.levelBox_ValueChanged);
            // 
            // levelLabel
            // 
            this.levelLabel.AutoSize = true;
            this.levelLabel.Location = new System.Drawing.Point(255, 21);
            this.levelLabel.Name = "levelLabel";
            this.levelLabel.Size = new System.Drawing.Size(36, 13);
            this.levelLabel.TabIndex = 15;
            this.levelLabel.Text = "Level:";
            // 
            // livesLabel
            // 
            this.livesLabel.AutoSize = true;
            this.livesLabel.Location = new System.Drawing.Point(255, 110);
            this.livesLabel.Name = "livesLabel";
            this.livesLabel.Size = new System.Drawing.Size(44, 13);
            this.livesLabel.TabIndex = 16;
            this.livesLabel.Text = "Lives: 0";
            // 
            // timerLabel
            // 
            this.timerLabel.AutoSize = true;
            this.timerLabel.Location = new System.Drawing.Point(255, 132);
            this.timerLabel.Name = "timerLabel";
            this.timerLabel.Size = new System.Drawing.Size(141, 13);
            this.timerLabel.TabIndex = 17;
            this.timerLabel.Text = "Timer: 60 frames per second";
            // 
            // passBox
            // 
            this.passBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.passBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.passBox.Font = new System.Drawing.Font("Arial monospaced for SAP", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passBox.Location = new System.Drawing.Point(0, 227);
            this.passBox.Multiline = true;
            this.passBox.Name = "passBox";
            this.passBox.ReadOnly = true;
            this.passBox.Size = new System.Drawing.Size(430, 53);
            this.passBox.TabIndex = 18;
            this.passBox.Text = "XZKC XBZM XXZD";
            this.passBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.Location = new System.Drawing.Point(9, 211);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(56, 13);
            this.passLabel.TabIndex = 19;
            this.passLabel.Text = "Password:";
            // 
            // lvlFCheck
            // 
            this.lvlFCheck.AutoSize = true;
            this.lvlFCheck.Location = new System.Drawing.Point(12, 178);
            this.lvlFCheck.Name = "lvlFCheck";
            this.lvlFCheck.Size = new System.Drawing.Size(78, 17);
            this.lvlFCheck.TabIndex = 20;
            this.lvlFCheck.Text = "Unknown?";
            this.lvlFCheck.UseVisualStyleBackColor = true;
            this.lvlFCheck.CheckedChanged += new System.EventHandler(this.lvlFCheck_CheckedChanged);
            // 
            // AR2gen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 280);
            this.Controls.Add(this.lvlFCheck);
            this.Controls.Add(this.passLabel);
            this.Controls.Add(this.passBox);
            this.Controls.Add(this.timerLabel);
            this.Controls.Add(this.livesLabel);
            this.Controls.Add(this.levelLabel);
            this.Controls.Add(this.levelBox);
            this.Controls.Add(this.lvlECheck);
            this.Controls.Add(this.lvlDCheck);
            this.Controls.Add(this.lvlCCheck);
            this.Controls.Add(this.lvlBCheck);
            this.Controls.Add(this.lvlACheck);
            this.Controls.Add(this.lvl9Check);
            this.Controls.Add(this.lvl8Check);
            this.Controls.Add(this.lvl7Check);
            this.Controls.Add(this.lvl6Check);
            this.Controls.Add(this.lvl5Check);
            this.Controls.Add(this.lvl4Check);
            this.Controls.Add(this.lvl3Check);
            this.Controls.Add(this.lvl2Check);
            this.Controls.Add(this.lvl1Check);
            this.Name = "AR2gen";
            this.Text = "ActRaiser 2 Password Generator";
            ((System.ComponentModel.ISupportInitialize)(this.levelBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox lvl1Check;
        private System.Windows.Forms.CheckBox lvl2Check;
        private System.Windows.Forms.CheckBox lvl3Check;
        private System.Windows.Forms.CheckBox lvl4Check;
        private System.Windows.Forms.CheckBox lvl5Check;
        private System.Windows.Forms.CheckBox lvl6Check;
        private System.Windows.Forms.CheckBox lvl7Check;
        private System.Windows.Forms.CheckBox lvl8Check;
        private System.Windows.Forms.CheckBox lvl9Check;
        private System.Windows.Forms.CheckBox lvlACheck;
        private System.Windows.Forms.CheckBox lvlBCheck;
        private System.Windows.Forms.CheckBox lvlCCheck;
        private System.Windows.Forms.CheckBox lvlDCheck;
        private System.Windows.Forms.CheckBox lvlECheck;
        private System.Windows.Forms.NumericUpDown levelBox;
        private System.Windows.Forms.Label levelLabel;
        private System.Windows.Forms.Label livesLabel;
        private System.Windows.Forms.Label timerLabel;
        private System.Windows.Forms.TextBox passBox;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.CheckBox lvlFCheck;
    }
}

