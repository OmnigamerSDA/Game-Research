﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    

    public partial class AR2gen : Form
    {
        readonly UInt16[] ROMTABLE = {5, 3, 2, 250, 210, 170, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55612, 0, 55634, 0, 55646, 0, 55678, 0, 0, 55710, 55732, 0, 55864, 55906, 0, 55918, 0, 0, 0, 55960, 0, 0, 0, 0, 0, 0, 0, 56032, 0, 0, 56408, 56430, 0, 0, 0, 0, 56430, 56532, 56594, 56646, 0, 56658, 0, 56760, 0, 0, 0, 0, 0, 56104, 56346, 0, 56782, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 56854, 56658, 56782, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 160, 39, 239, 8, 216, 160, 263, 239, 8, 65535, 1304, 64, 1399, 159, 20, 65535, 1384, 144, 1431, 223, 20, 1416, 112, 1463, 191, 20, 1448, 16, 1543, 159, 20, 65535, 72, 416, 151, 495, 20, 456, 576, 695, 655, 20, 280, 960, 695, 1039, 20, 65535, 1720, 880, 1991, 943, 8, 392, 272, 919, 351, 8, 65535, 88, 544, 167, 607, 8, 56, 816, 119, 879, 8, 56, 1024, 135, 1087, 8, 104, 1232, 199, 1295, 8, 56, 1344, 151, 1407, 8, 136, 1472, 199, 1535, 8, 56, 1520, 119, 1583, 8, 104, 1680, 199, 1743, 8, 56, 1792, 151, 1855, 8, 136, 1872, 199, 1935, 8, 88, 2016, 167, 2079, 8, 56, 2128, 119, 2191, 8, 136, 2128, 199, 2191, 8, 65535, 584, 928, 663, 1007 };
        readonly byte[] ASCIITABLE = {83, 84, 88, 87, 70, 72, 74, 75, 90, 66, 67, 68, 89, 76, 77, 80};
        //                            S,  T,  X,  W,  F,  H,  J,  K,  Z,  B,  C,  D,  Y,  L,  M,  P
        //                            0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15


        public AR2gen()
        {
            InitializeComponent();
        }
        

        private void UpdatePassword()
        {
            UInt16[] addr90C = CalcLevels();
            byte[] passString = CalcPassword(addr90C);//{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            passBox.Text = string.Format("{0}{1}{2}{3} {4}{5}{6}{7} {8}{9}{10}{11}", (char)passString[0], (char)passString[1], (char)passString[2], (char)passString[3], (char)passString[4], (char)passString[5], (char)passString[6], (char)passString[7], (char)passString[8], (char)passString[9], (char)passString[10], (char)passString[11]);
        }

        private byte[] CalcPassword(ushort[] addr90C)
        {
            UInt16[] addr508 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            byte[] passString = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            byte carry = 0;
            ushort checksum = 0;

            int i,j, lookup = 0;

            for (i = 0; i < 5; i++)
            {
                checksum = addr508[0];
                addr508[0] += (ushort)(addr90C[i]);// + carry);

                

                if (addr508[0] > 255)
                    addr508[0] -= 256;

                //if (addr508[0] > 127)
                //    carry = 1;
                //else
                //    carry = 0;

                lookup = addr508[0] & 0x0F;

                passString[i * 2] = ASCIITABLE[lookup];

                addr508[15] = passString[i * 2];

                addr508 = CalcSum(addr508);

                addr508[0] += (ushort)((addr90C[i] >> 4));//+carry);

                if (addr508[0] > 255)
                    addr508[0] -= 256;

                lookup = addr508[0] & 0x0F;

                passString[(i * 2) + 1] = ASCIITABLE[lookup];

                addr508[15] = passString[(i * 2) + 1];

                addr508 = CalcSum(addr508);

                //if (addr508[0] > 255)
                //{
                //    carry = 1;
                //    addr508[0] -= 256;
                //}
                //else
                //    carry = 0;
            }


            lookup = addr508[0] & 0x0F;

            passString[10] = ASCIITABLE[lookup];

            lookup = (addr508[0] >> 4) & 0x0F;

            passString[11] = ASCIITABLE[lookup];

            return passString;

        }

        private ushort[] CalcSum(ushort[] addr508)
        {
            int i = 15;
            ushort carry=0;

            for (i = 15; i > 0; i--)
            {
                addr508[i - 1] += (ushort)(addr508[i] + carry);

                if (addr508[i - 1] > 255)
                {
                    addr508[i - 1] -= 256;
                    carry = 1;
                }
                else
                    carry = 0;
            }

            //addr508[15] += 1;
            //if (addr508[15] > 255)
            //    addr508[15] -= 256;

            return addr508;
        }

        private ushort[] CalcLevels()
        {

            UInt16[] addr90C = { 0, 0, 0, 0, 0 };

            if (lvl1Check.Checked)
            {
                addr90C[0] += 2;
            }

            if (lvl2Check.Checked)
            {
                addr90C[0] += 4;
            }

            if (lvl3Check.Checked)
            {
                addr90C[0] += 8;
            }

            if (lvl4Check.Checked)
            {
                addr90C[0] += 16;
            }

            if (lvl5Check.Checked)
            {
                addr90C[0] +=32;
            }

            if (lvl6Check.Checked)
            {
                addr90C[0] += 64;
            }

            if (lvl7Check.Checked)
            {
                addr90C[1] += 1;
            }

            if (lvl8Check.Checked)
            {
                addr90C[1] += 4;
            }

            if (lvl9Check.Checked)
            {
                addr90C[1] += 8;
            }

            if (lvlACheck.Checked)
            {
                addr90C[1] += 16;
            }

            if (lvlBCheck.Checked)
            {
                addr90C[1] += 64;
            }

            if (lvlCCheck.Checked)
            {
                addr90C[2] += 2;
            }

            if (lvlDCheck.Checked)
            {
                addr90C[2] += 4;
            }

            if (lvlECheck.Checked)
            {
                addr90C[2] += 32;
            }

            if (lvlFCheck.Checked)
            {
                addr90C[3] += 128;
            }

            addr90C[4] = (ushort)levelBox.Value;

            return addr90C;
        }


        private void UpdateDifficulty()
        {
            int diff = (int)levelBox.Value;

            livesLabel.Text = string.Format("Lives:    {0}", ROMTABLE[diff]);
            timerLabel.Text = string.Format("Timer:    {0} frames per second", ROMTABLE[diff+3]);
        }

        private void lvl1Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl2Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl3Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl4Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl5Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl6Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl7Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl8Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvl9Check_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvlACheck_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvlBCheck_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvlCCheck_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvlDCheck_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvlECheck_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void lvlFCheck_CheckedChanged(object sender, EventArgs e)
        {
            UpdatePassword();
        }

        private void levelBox_ValueChanged(object sender, EventArgs e)
        {
            UpdatePassword();
            UpdateDifficulty();
        }

    }
}
