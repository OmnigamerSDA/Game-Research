-- Requirement
-- http://code.google.com/p/pcsxrr/
-- http://luaforge.net/frs/?group_id=23&release_id=837

-- Usefull game info
-- http://www.gamefaqs.com/console/psx/file/198844/7234
-- http://www.suikosource.com/games/gs2/guides/itemdigits.php

require("socket")
emu = pcsx;
input = joypad.read(1);
--memory.readbyte(int addr)

function sleep(sec)
    socket.select(nil, nil, sec)
end

function macro()
    input = joypad.read(1)	
	if input["l3"] and input["r3"] then
		emu.speedmode("maximum") -- "normal" "nothrottle" "turbo"
		sleep(0.8)
	elseif input["l3"] then
		emu.speedmode("turbo") -- "normal" "nothrottle" "turbo"
	elseif input["r3"] then
		emu.speedmode("normal") -- "normal" "nothrottle" "turbo"
		
	end
end

function r(i)
    if(i == 1) then
	return 0
	else
	return 1
	end	
end


--buttonNames = {"select","l3","r3","start","up","right","down","left",   
--             "l2","r2","l1","r1","triangle","circle","x","square"}



buttonNames = {"up","right","down","left"}
buttonsCount = 4

possibility = {}
	-----------------
	--1 frame avec 4 boutons... 16 possibilit�es: 
	
	--idle
	-- = = = =
	
	-- 1 buttons
	-- + = = =
	-- = + = =
	-- = = + =
	-- = = = +
	
	-- 2 buttons
	-- + + = =
	-- + = + =
	-- + = = +
	-- = + + =
	-- = + = +
	-- = = + +
	
	-- 3 buttons
	-- + + + =
	-- + + = +
	-- + = + +
	-- = + + +
	
	-- 4 buttons
	-- + + + +
	-----------------
	
	possibility[1] = {nil, nil, nil, nil}
	
	possibility[2] = {true, nil, nil, nil}
	possibility[3] = {nil, true, nil, nil}
	possibility[4] = {nil, nil, true, nil}
	possibility[5] = {nil, nil, nil, true}
	
	possibility[6] = {true, true, nil, nil}
	possibility[7] = {true, nil, true, nil}
	possibility[8] = {true, nil, nil, true}
	possibility[9] = {nil, true, true, nil}
	possibility[10] = {nil, true, nil, true}
	possibility[11] = {nil, nil, true, true}
	
	possibility[12] = {true, true, true, nil}
	possibility[13] = {true, true, nil, true}
	possibility[14] = {true, nil, true, true}
	possibility[15] = {nil, true, true,true}
	
	possibility[16] = {true, true, true, true}




frameNumber = 0
pad = joypad.read(1)	

local startMem = 0x0;
local maxMem = 0x001FFFFF;

local MAXFrame = 7


local start = savestate.create(); 


	--sleep(0.0166)
	--for i = 0, maxMem, 1 do
		--memory.readbyte(0x0 + i)
	--end
	
	
	savestate.save(start); 
	
	for f = 1,MAXFrame,1 do -- f pour le nombre de frame a passer
	
	
		for i = 1, 16, 1 do -- i pour bouton
			for j = 1, 16, 1 do
				for k = 1, 16, 1 do
					for l = 1, 16, 1 do
						for m = 1, 16, 1 do
		--possibilit� 1 frame					
			pad[buttonNames[1]] = possibility[i][1]
			pad[buttonNames[2]] = possibility[i][2]
			pad[buttonNames[3]] = possibility[i][3]
			pad[buttonNames[4]] = possibility[i][4]
		
			joypad.set(1,pad)
			emu.frameadvance()
			--frame 2
			----TODO a 2 frame il ne cesse de r�p�ter plusieurs fois la meme combinaise avant de passer a une autre
			pad[buttonNames[1]] = possibility[j][1]
			pad[buttonNames[2]] = possibility[j][2]
			pad[buttonNames[3]] = possibility[j][3]
			pad[buttonNames[4]] = possibility[j][4]
		
			joypad.set(1,pad)
			emu.frameadvance()
			--frame 3
			pad[buttonNames[1]] = possibility[k][1]
			pad[buttonNames[2]] = possibility[k][2]
			pad[buttonNames[3]] = possibility[k][3]
			pad[buttonNames[4]] = possibility[k][4]
		
			joypad.set(1,pad)
			emu.frameadvance()
			--frame 4
			pad[buttonNames[1]] = possibility[l][1]
			pad[buttonNames[2]] = possibility[l][2]
			pad[buttonNames[3]] = possibility[l][3]
			pad[buttonNames[4]] = possibility[l][4]
		
			joypad.set(1,pad)
			emu.frameadvance()
			--frame 5
			pad[buttonNames[1]] = possibility[m][1]
			pad[buttonNames[2]] = possibility[m][2]
			pad[buttonNames[3]] = possibility[m][3]
			pad[buttonNames[4]] = possibility[m][4]
		
			joypad.set(1,pad)
			emu.frameadvance()
			
			if(memory.readbyte(0x06A46A) == 75) then --objective
				pcsx.message("yeayyyyyy")
			else
				savestate.load(start); 
			end
						end
					end
				end
			end
		end
		
		
		
		
		
end
	
	
	
while true do
	pcsx.message("tested everything")
	emu.frameadvance()	
end


-- Read current input
-- input = joypad.read(1)

-- Set input
-- joypad.set(1,input)

-- If example
-- if input[buttonNames[1]] then
-- else
-- end

-- Writing text
-- gui.text(10,  40, "yeahhh")

-- Memory
--		if(memory.readbyte(0x0001B426 + i) == 164) then
--			memory.writebyte(0x0001B426 +i, 0x11)

-- Clear the screen
-- gui.clearuncommitted()

-- Frame Advance
-- emu.frameadvance()

-- SpeedMode
-- emu.speedmode() -- "normal" "nothrottle" "turbo" "maximum"
-- emu.pause()
-- emu.unpause()

-- Sleep
-- sleep(0.2)



