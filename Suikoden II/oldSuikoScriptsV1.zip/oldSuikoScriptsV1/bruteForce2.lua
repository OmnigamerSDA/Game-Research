-- Requirement
-- http://code.google.com/p/pcsxrr/
-- http://luaforge.net/frs/?group_id=23&release_id=837

-- Usefull game info
-- http://www.gamefaqs.com/console/psx/file/198844/7234
-- http://www.suikosource.com/games/gs2/guides/itemdigits.php

require("socket")
emu = pcsx;
input = joypad.read(1);
--memory.readbyte(int addr)

function sleep(sec)
    socket.select(nil, nil, sec)
end

function macro()
    input = joypad.read(1)	
	if input["l3"] and input["r3"] then
		emu.speedmode("maximum") -- "normal" "nothrottle" "turbo"
		sleep(0.8)
	elseif input["l3"] then
		emu.speedmode("turbo") -- "normal" "nothrottle" "turbo"
	elseif input["r3"] then
		emu.speedmode("normal") -- "normal" "nothrottle" "turbo"
		
	end
end

function r(i)
    if(i == 1) then
	return 0
	else
	return 1
	end	
end


--buttonNames = {"select","l3","r3","start","up","right","down","left",   
--             "l2","r2","l1","r1","triangle","circle","x","square"}



buttonNames = {"up","right","down","left"}
buttonsCount = 4

possibility = {}
	-----------------
	--1 frame avec 4 boutons... 16 possibilit�es: 
	
	--idle
	-- = = = =
	
	-- 1 buttons
	-- + = = =
	-- = + = =
	-- = = + =
	-- = = = +
	
	-- 2 buttons
	-- + + = =
	-- + = + =
	-- + = = +
	-- = + + =
	-- = + = +
	-- = = + +
	
	-- 3 buttons
	-- + + + =
	-- + + = +
	-- + = + +
	-- = + + +
	
	-- 4 buttons
	-- + + + +
	-----------------
	
	possibility[1] = {nil, nil, nil, nil}
	
	possibility[2] = {true, nil, nil, nil}
	possibility[3] = {nil, true, nil, nil}
	possibility[4] = {nil, nil, true, nil}
	possibility[5] = {nil, nil, nil, true}
	
	possibility[6] = {true, true, nil, nil}
	possibility[7] = {true, nil, true, nil}
	possibility[8] = {true, nil, nil, true}
	possibility[9] = {nil, true, true, nil}
	possibility[10] = {nil, true, nil, true}
	possibility[11] = {nil, nil, true, true}
	
	possibility[12] = {true, true, true, nil}
	possibility[13] = {true, true, nil, true}
	possibility[14] = {true, nil, true, true}
	possibility[15] = {nil, true, true,true}
	
	possibility[16] = {true, true, true, true}




frameNumber = 0

local startMem = 0x0;
local maxMem = 0x001FFFFF;

local MAXFrame = 7


local start = savestate.create(); 


	--sleep(0.0166)
	--for i = 0, maxMem, 1 do
		--memory.readbyte(0x0 + i)
	--end
	
	
	emu.speedmode("turbo")
	savestate.save(start); 	
pad = joypad.read(1)

	pad["circle"] = true
local attempt = 21; -- 21 et moins checked!
local unSuccess = true	
while unSuccess do

	for f = 1,attempt,1 do -- f pour le nombre de frame a passer
				
			pad["circle"] = true
			pad["down"] = nil
			pad["up"] = true			
			joypad.set(1,pad)
			emu.frameadvance()
			
			pad["circle"] = true
			pad["down"] = nil
			pad["up"] = true			
			joypad.set(1,pad)
			emu.frameadvance()
			
			pad["circle"] = true
			pad["up"] = nil
			pad["down"] = true
			joypad.set(1,pad)
			emu.frameadvance()
			pad["circle"] = true
			pad["up"] = nil
			pad["down"] = true			
			joypad.set(1,pad)
			emu.frameadvance()
			
	end
	
			pad["circle"] = true	
			pad["up"] = nil
			pad["down"] = nil
			pad["left"] = true
			joypad.set(1,pad)
			emu.frameadvance()
			
			pad["circle"] = true	
			pad["up"] = nil
			pad["down"] = nil
			pad["left"] = true
			joypad.set(1,pad)
			emu.frameadvance()
			
			pad["left"] = nil
			pad["circle"] = nil
			
			
			for i = 1,500,1 do	
			
				pad["up"] = true
				joypad.set(1,pad)
				emu.frameadvance()			
				if(memory.readbyte(0x06A46A) ~= 0) then --objective
					unSuccess = nil
					savestate.save(start); 
				end
			end
			
			attempt = attempt +1;
			savestate.load(start);
			gui.text(10,  40, "attempt : " .. attempt)
			
	
end

savestate.load(start);
	
while true do
	pcsx.message("You got it!!!")
	emu.frameadvance()	
	end
	



-- Read current input
-- input = joypad.read(1)

-- Set input
-- joypad.set(1,input)

-- If example
-- if input[buttonNames[1]] then
-- else
-- end

-- Writing text
-- gui.text(10,  40, "yeahhh")

-- Memory
--		if(memory.readbyte(0x0001B426 + i) == 164) then
--			memory.writebyte(0x0001B426 +i, 0x11)

-- Clear the screen
-- gui.clearuncommitted()

-- Frame Advance
-- emu.frameadvance()

-- SpeedMode
-- emu.speedmode() -- "normal" "nothrottle" "turbo" "maximum"
-- emu.pause()
-- emu.unpause()

-- Sleep
-- sleep(0.2)




	