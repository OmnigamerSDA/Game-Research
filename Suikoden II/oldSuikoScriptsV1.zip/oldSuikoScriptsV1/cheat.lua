-- Requirement
-- http://code.google.com/p/pcsxrr/
-- http://luaforge.net/frs/?group_id=23&release_id=837

-- Usefull game info
-- http://www.gamefaqs.com/console/psx/file/198844/7234
-- http://www.suikosource.com/games/gs2/guides/itemdigits.php

for i = 0x01B712D, 0x001B7140 do
		--refugee from matilda battle
		
		--riou attk/def
		memory.writebyte(0x001B6E40, 98)
		memory.writebyte(0x001B6E42, 98)

		--riou 1
		memory.writebyte(0x001B6E31, 0x0c)
		memory.writebyte(0x001B6E34, 9)
		
		--riou 2
		memory.writebyte(0x001B6E32, 0x03)
		memory.writebyte(0x001B6E35, 9)	
	
		--riou 3
		memory.writebyte(0x001B6E33, 0x12)
		memory.writebyte(0x001B6E36, 9)		
				
		
		--nanami 1
		memory.writebyte(0x001B7129, 0x19)
		memory.writebyte(0x001B712C, 9)
		
		--nanami 2
		memory.writebyte(0x001B712A, 0x01)
		memory.writebyte(0x001B712D, 9)
		
		--nanami 3
		memory.writebyte(0x001B712B, 0x15)
		memory.writebyte(0x001B712E, 9)
		
		--avatar 1
		--memory.writebyte(0x001B6E37, 1)	
		
end

-- Read current input
-- input = joypad.read(1)

-- Set input
-- joypad.set(1,input)

-- If example
-- if input[buttonNames[1]] then
-- else
-- end

-- Writing text
-- gui.text(10,  40, "yeahhh")

-- Memory
--		if(memory.readbyte(0x0001B426 + i) == 164) then
--			memory.writebyte(0x0001B426 +i, 0x11)

-- Clear the screen
-- gui.clearuncommitted()

-- Frame Advance
-- emu.frameadvance()

-- SpeedMode
-- emu.speedmode() -- "normal" "nothrottle" "turbo" "maximum"
-- emu.pause()
-- emu.unpause()

-- Sleep
-- sleep(0.2)



