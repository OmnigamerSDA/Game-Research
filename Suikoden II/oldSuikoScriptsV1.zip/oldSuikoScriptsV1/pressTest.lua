emu = pcsx;
pad = joypad.read(1)
start = savestate.create()
framecounter = 0
address = 0x197794

buttonNames = {select="select",l3="l3",r3="r3",start="start",up="up",right="right",down="down",left="left",   
             l2="l2",r2="r2",l1="l1",r1="r1",triangle="triangle",circle="circle",x="x",square="square"}

while (framecounter) < 100 do
	framecounter = framecounter +1;
	-- framecounter = emu.framecount()

	savestate.save(start);

	while (memory.readbyte(address)) == 0 do
		pad[buttonNames["square"]] = true
		joypad.set(1,pad)
		emu.frameadvance(); framecounter = framecounter +1;
		-- emu.frameadvance();

		pad[buttonNames["square"]] = nil
	end

	savestate.load(start); -- basicly the following code should never happen, because once 0x197794 isn't 0 we're comming back to the "start" savestate

	pad[buttonNames["right"]] = true
	joypad.set(1,pad)
	emu.frameadvance(); framecounter = framecounter +1;
	-- emu.frameadvance(); 

	pad[buttonNames["right"]] = nil
	joypad.set(1,pad)

	emu.frameadvance(); framecounter = framecounter +1;
	-- emu.frameadvance();
	emu.frameadvance(); framecounter = framecounter +1;
	-- emu.frameadvance();

end