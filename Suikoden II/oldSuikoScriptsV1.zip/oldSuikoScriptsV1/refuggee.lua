emu = pcsx;
pad = joypad.read(1)
start = savestate.create()
framecounter = 0
address = 0x197794
objective = false
attempt = 1

savestate.save(start);

buttonNames = {select="select",l3="l3",r3="r3",start="start",up="up",right="right",down="down",left="left",   
             l2="l2",r2="r2",l1="l1",r1="r1",triangle="triangle",circle="circle",x="x",square="square"}

			 
			 
while not objective do

for i = 0, attempt do
	pad[buttonNames["up"]] = nil

	pad[buttonNames["circle"]] = true
	pad[buttonNames["down"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["circle"]] = true
	pad[buttonNames["down"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["down"]] = nil --change de direction
	
	pad[buttonNames["circle"]] = true
	pad[buttonNames["up"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["circle"]] = true
	pad[buttonNames["up"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
end



	pad[buttonNames["up"]] = nil
	pad[buttonNames["down"]] = nil
	
	--2 frame a gauche
	pad[buttonNames["circle"]] = true
	pad[buttonNames["left"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["circle"]] = true
	pad[buttonNames["left"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["left"]] = nil
	--2frame a droite
	pad[buttonNames["circle"]] = true
	pad[buttonNames["right"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["circle"]] = true
	pad[buttonNames["right"]] = true
	joypad.set(1,pad)
	emu.frameadvance();
	
	pad[buttonNames["right"]] = nil
	
	for i = 0, 60 do
		pad[buttonNames["circle"]] = true
		pad[buttonNames["up"]] = true
		joypad.set(1,pad)
		emu.frameadvance();
	end
	
	pad[buttonNames["circle"]] = nil
	pad[buttonNames["up"]] = nil
	pad[buttonNames["down"]] = nil
	pad[buttonNames["right"]] = nil
	pad[buttonNames["left"]] = nil
	
	while not (emu.framecount() > 794000) do --limite ok??		
		pad[buttonNames["l1"]] = true
		pad[buttonNames["x"]] = nil
		joypad.set(1,pad)
		emu.frameadvance();
		
		pad[buttonNames["l1"]] = nil
		pad[buttonNames["x"]] = true
		joypad.set(1,pad)
		emu.frameadvance();
	end
	
	--refugier 1, refugier 2, refugier 3...
	if(memory.readbyte(0x001BE2A5) > 1 and memory.readbyte(0x001BE2B9) > 1 and memory.readbyte(0x001BE2CD) > 1) then
		objective = true;
		savestate.save(start);
	end
	attempt = attempt +1;
	gui.text(10,  40, "nombre de test : " .. attempt)
	
	savestate.load(start);
end

savestate.load(start);