counter = 0xD8;
test = savestate.create();
savestate.save(test)
while true do
	for i =0, 75 do	
		memory.writebyte(0x0001B42A, counter);	
		pcsx.frameadvance();
	end
	print("Attempt # " .. counter)
	gui.text(5, 25, "Attempt # " .. counter .. " // 0x" .. string.format("%X", counter))
	counter = counter +1;
	savestate.load(test)
end