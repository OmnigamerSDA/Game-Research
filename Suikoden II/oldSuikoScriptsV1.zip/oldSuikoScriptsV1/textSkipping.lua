-- Requirement
-- http://code.google.com/p/pcsxrr/
-- http://luaforge.net/frs/?group_id=23&release_id=837

-- Usefull game info
-- http://www.gamefaqs.com/console/psx/file/198844/7234
-- http://www.suikosource.com/games/gs2/guides/itemdigits.php

require("socket")
function sleep(sec)
    socket.select(nil, nil, sec)
end
emu = pcsx;

local buttonNames = {"select","l3","r3","start","up","right","down","left",   
             "l2","r2","l1","r1","triangle","circle","x","square"}
pad = joypad.read(1)

while true do

	pad[buttonNames[11]] = true
	pad[buttonNames[15]] = nil
	joypad.set(1,pad)
	emu.frameadvance()	
	
	pad[buttonNames[11]] = nil
	pad[buttonNames[15]] = true
	joypad.set(1,pad)
	emu.frameadvance()	
	

end


-- Read current input
-- input = joypad.read(1)

-- Set input
-- joypad.set(1,input)

-- If example
-- if input[buttonNames[1]] then
-- else
-- end

-- Writing text
-- gui.text(10,  40, "yeahhh")

-- Memory
--		if(memory.readbyte(0x0001B426 + i) == 164) then
--			memory.writebyte(0x0001B426 +i, 0x11)

-- Clear the screen
-- gui.clearuncommitted()

-- Frame Advance
-- emu.frameadvance()

-- SpeedMode
-- emu.speedmode() -- "normal" "nothrottle" "turbo" "maximum"
-- emu.pause()
-- emu.unpause()

-- Sleep
-- sleep(0.2)



