-- Requirement
-- http://code.google.com/p/pcsxrr/
-- http://luaforge.net/frs/?group_id=23&release_id=837

-- Usefull game info
-- http://www.gamefaqs.com/console/psx/file/198844/7234
-- http://www.suikosource.com/games/gs2/guides/itemdigits.php

require("socket")
emu = pcsx;
input = joypad.read(1);
--memory.readbyte(int addr)

function sleep(sec)
    socket.select(nil, nil, sec)
end


local addresse1 = 0x001FFED6
local addresse2 = 0x001FFEDC
local test1 = 0
local test2 = 0
local sleepTime = 2

while true do
	-- TODO: Ajouter des conditions pour �viter d'avoir des pause en combats et
	--		 essayer de trouver un moyen d'avoir des pauses entre deux dialogues d'une meme textBox
	
	if(memory.readbyte(addresse1) >= 246 and memory.readbyte(0x001FFED6) <= 255) then
		test1 = test1 + 1
	end	
	
	if(memory.readbyte(addresse2) >= 246 and memory.readbyte(addresse2) <= 255) then
		test2 = test2 + 1
	end
	
	if(memory.readbyte(addresse1) < 246 or memory.readbyte(addresse1) > 255) then
		if(test1 > 1) then
			sleep(sleepTime)
			test1 = 0
			test2 = 0
		end
	end
	
	if(memory.readbyte(addresse2) < 246 or memory.readbyte(addresse2) > 255) then
		if(test2 > 1) then
			sleep(sleepTime)
			test1 = 0
			test2 = 0
		end
	end
	gui.text(10,  40, "test1 " .. test1)
	gui.text(10,  50, "test2 " .. test2)
	
	emu.speedmode("turbo")
	sleep(0.0086)
	emu.frameadvance()
	
	
	--sleep(0.00002)

end


-- Read current input
-- input = joypad.read(1)

-- Set input
-- joypad.set(1,input)

-- If example
-- if input[buttonNames[1]] then
-- else
-- end

-- Writing text
-- gui.text(10,  40, "yeahhh")

-- Memory
--		if(memory.readbyte(0x0001B426 + i) == 164) then
--			memory.writebyte(0x0001B426 +i, 0x11)

-- Clear the screen
-- gui.clearuncommitted()

-- Frame Advance
-- emu.frameadvance()

-- SpeedMode
-- emu.speedmode() -- "normal" "nothrottle" "turbo" "maximum"
-- emu.pause()
-- emu.unpause()

-- Sleep
-- sleep(0.2)



